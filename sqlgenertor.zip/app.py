from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
from google import generativeai as genai
from dotenv import load_dotenv
from urllib.parse import unquote
import os
import re
import MySQLdb

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-1.5-flash")

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change_this!")
CORS(app)

query_cache = {}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/set_db", methods=["POST"])
def set_db():
    creds = request.get_json()
    session['db_host'] = creds.get('host')
    session['db_user'] = creds.get('user')
    session['db_pass'] = unquote(creds.get('pass', '')).strip()
    session['db_name'] = creds.get('db')
    return jsonify({"status": "Credentials saved"})

@app.route("/generate_sql", methods=["POST"])
def generate_sql():
    raw_data = request.json.get("raw_data", "")
    table_name = "records"
    session['last_table'] = table_name

    prompt = f"""
You are a helpful assistant that converts CSV-like plain text into SQL commands.
Input:
{raw_data}

Output SQL:
1. CREATE TABLE statement for MySQL, infer correct datatypes.
2. INSERT INTO statement(s) for the rows.
Table name: {table_name}
"""

    try:
        response = model.generate_content(prompt)
        generated_sql = re.sub(r"^```[\w]*\s*|```$", "", response.text.strip(), flags=re.IGNORECASE).strip()

        conn = MySQLdb.connect(
            host=session.get("db_host"),
            user=session.get("db_user"),
            passwd=session.get("db_pass"),
            db=session.get("db_name"),
            charset="utf8mb4",
            autocommit=True
        )
        cursor = conn.cursor()
        for stmt in generated_sql.split(";"):
            if stmt.strip():
                cursor.execute(stmt + ";")
        conn.close()

        return jsonify({"sql": generated_sql, "table": table_name})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/db_rows", methods=["GET", "POST"])
def db_rows():
    try:
        conn = MySQLdb.connect(
            host=session.get("db_host"),
            user=session.get("db_user"),
            passwd=session.get("db_pass"),
            db=session.get("db_name"),
            charset="utf8mb4"
        )
        cursor = conn.cursor()

        if request.method == "POST":
            data = request.get_json()
            table = data.get("table")
        else:
            table = session.get("last_table")

        if not table:
            cursor.execute("SHOW TABLES;")
            tables = cursor.fetchall()
            return jsonify({
                "error": "No table selected or created yet.",
                "available_tables": [t[0] for t in tables]
            })

        cursor.execute(f"SELECT * FROM `{table}`;")
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        conn.close()

        return jsonify([dict(zip(columns, row)) for row in rows])
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/ask", methods=["POST"])
def ask_query():
    try:
        user_text = request.json.get("query", "").strip().lower()
        table = session.get("last_table")
        if not table:
            return jsonify({"error": "No table loaded to query."})

        if user_text in query_cache:
            sql = query_cache[user_text]
        else:
            conn = MySQLdb.connect(
                host=session.get("db_host"),
                user=session.get("db_user"),
                passwd=session.get("db_pass"),
                db=session.get("db_name"),
                charset="utf8mb4"
            )
            cursor = conn.cursor()
            cursor.execute(f"DESCRIBE `{table}`;")
            schema = cursor.fetchall()
            column_names = [col[0] for col in schema]
            conn.close()

            prompt = f"""
You are an AI that translates user questions into SQL queries.
Given this table: {table}
Columns: {', '.join(column_names)}
User asked: "{user_text}"
Return ONLY the SQL query that answers this question.
"""
            response = model.generate_content(prompt)
            sql = re.sub(r"^```[\w]*\s*|```$", "", response.text.strip(), flags=re.IGNORECASE).strip()
            query_cache[user_text] = sql

        conn = MySQLdb.connect(
            host=session.get("db_host"),
            user=session.get("db_user"),
            passwd=session.get("db_pass"),
            db=session.get("db_name"),
            charset="utf8mb4"
        )
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        conn.close()

        return jsonify({"query": sql, "results": [dict(zip(columns, row)) for row in rows]})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)